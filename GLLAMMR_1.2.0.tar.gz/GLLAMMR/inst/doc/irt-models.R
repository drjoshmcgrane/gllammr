## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)

## ----rasch-simulation---------------------------------------------------------
library(GLLAMMR)

set.seed(123)
n_persons <- 300
n_items <- 12

# True parameters
true_ability <- rnorm(n_persons, mean = 0, sd = 1)
true_difficulty <- seq(-2, 2, length.out = n_items)

# Generate responses
responses <- matrix(NA, n_persons, n_items)
for (j in 1:n_items) {
  p <- plogis(true_ability - true_difficulty[j])
  responses[, j] <- rbinom(n_persons, 1, p)
}
colnames(responses) <- paste0("Item", 1:n_items)

head(responses)

## ----fit-rasch----------------------------------------------------------------
fit_rasch <- fit_irt(responses, model = "Rasch")

print(fit_rasch)

## ----rasch-items--------------------------------------------------------------
# Item difficulties
item_params <- fit_rasch$item_parameters
print(item_params)

# Plot item difficulties
plot(true_difficulty, item_params$difficulty,
     xlab = "True Difficulty",
     ylab = "Estimated Difficulty",
     main = "Rasch Model: Parameter Recovery")
abline(0, 1, col = "red", lty = 2)

## ----rasch-persons------------------------------------------------------------
# Person abilities (empirical Bayes estimates)
abilities_rasch <- fit_rasch$person_abilities

# Distribution of abilities
hist(abilities_rasch, main = "Distribution of Estimated Abilities",
     xlab = "Ability (theta)", col = "lightblue")

# Correlation with true abilities
cor(abilities_rasch, true_ability)

## ----2pl-simulation-----------------------------------------------------------
set.seed(456)
n_items_2pl <- 10

true_difficulty_2pl <- rnorm(n_items_2pl, 0, 1)
true_discrimination <- runif(n_items_2pl, 0.8, 2.0)

responses_2pl <- matrix(NA, n_persons, n_items_2pl)
for (j in 1:n_items_2pl) {
  p <- plogis(true_discrimination[j] * (true_ability - true_difficulty_2pl[j]))
  responses_2pl[, j] <- rbinom(n_persons, 1, p)
}
colnames(responses_2pl) <- paste0("Q", 1:n_items_2pl)

## ----fit-2pl------------------------------------------------------------------
fit_2pl <- fit_irt(responses_2pl, model = "2PL")

print(fit_2pl)
summary(fit_2pl)

## ----2pl-params---------------------------------------------------------------
difficulty_2pl <- fit_2pl$item_parameters$difficulty
discrimination_2pl <- fit_2pl$item_parameters$discrimination

plot(true_difficulty_2pl, difficulty_2pl,
     xlab = "True Difficulty", ylab = "Estimated Difficulty",
     main = "2PL: Difficulty Recovery")
abline(0, 1, col = "red", lty = 2)

plot(true_discrimination, discrimination_2pl,
     xlab = "True Discrimination", ylab = "Estimated Discrimination",
     main = "2PL: Discrimination Recovery")
abline(0, 1, col = "red", lty = 2)

## ----fit-3pl------------------------------------------------------------------
set.seed(789)
true_guessing <- runif(n_items_2pl, 0.1, 0.3)

responses_3pl <- matrix(NA, n_persons, n_items_2pl)
for (j in 1:n_items_2pl) {
  p <- true_guessing[j] + (1 - true_guessing[j]) *
       plogis(true_discrimination[j] * (true_ability - true_difficulty_2pl[j]))
  responses_3pl[, j] <- rbinom(n_persons, 1, p)
}

fit_3pl <- fit_irt(responses_3pl, model = "3PL")

print(fit_3pl)

## ----icc, fig.width=7, fig.height=6-------------------------------------------
plot_icc_rasch <- function(difficulty, theta_range = c(-3, 3)) {
  theta <- seq(theta_range[1], theta_range[2], length.out = 100)
  p <- plogis(theta - difficulty)

  plot(theta, p, type = "l", lwd = 2,
       xlab = "Ability (theta)",
       ylab = "P(Correct)",
       main = paste("ICC: Difficulty =", round(difficulty, 2)),
       ylim = c(0, 1))
  abline(h = 0.5, col = "gray", lty = 2)
  abline(v = difficulty, col = "red", lty = 2)
}

oldpar <- par(mfrow = c(2, 2))
plot_icc_rasch(item_params$difficulty[1])
plot_icc_rasch(item_params$difficulty[4])
plot_icc_rasch(item_params$difficulty[8])
plot_icc_rasch(item_params$difficulty[12])
par(oldpar)

## ----iif, fig.width=6, fig.height=4.5-----------------------------------------
item_information_2pl <- function(theta, a, b) {
  p <- plogis(a * (theta - b))
  a^2 * p * (1 - p)
}

theta_grid <- seq(-3, 3, length.out = 100)

plot(theta_grid, item_information_2pl(theta_grid, a = 0.5, b = 0),
     type = "l", lwd = 2, col = "blue",
     xlab = "Ability", ylab = "Information",
     main = "Item Information: Effect of Discrimination",
     ylim = c(0, 1))
lines(theta_grid, item_information_2pl(theta_grid, a = 1.0, b = 0),
      lwd = 2, col = "green")
lines(theta_grid, item_information_2pl(theta_grid, a = 2.0, b = 0),
      lwd = 2, col = "red")
legend("topright",
       legend = c("a = 0.5", "a = 1.0", "a = 2.0"),
       col = c("blue", "green", "red"),
       lwd = 2)

## ----model-comparison---------------------------------------------------------
fit_rasch_on_2pl <- fit_irt(responses_2pl, model = "Rasch")

comparison <- data.frame(
  Model = c("Rasch", "2PL"),
  LogLik = c(fit_rasch_on_2pl$logLik, fit_2pl$logLik),
  AIC = c(fit_rasch_on_2pl$AIC, fit_2pl$AIC),
  BIC = c(fit_rasch_on_2pl$BIC, fit_2pl$BIC)
)

print(comparison)
# Lower AIC/BIC is better; 2PL should fit better here because the
# generating discriminations vary across items

## ----ability-est--------------------------------------------------------------
# Create ability score groups
ability_groups <- cut(abilities_rasch,
                      breaks = quantile(abilities_rasch, c(0, 0.25, 0.5, 0.75, 1)),
                      include.lowest = TRUE,
                      labels = c("Low", "Medium-Low", "Medium-High", "High"))

# Average proportion correct by ability group
score_by_group <- tapply(rowMeans(responses), ability_groups, mean)
print(score_by_group)

## ----grm-simulation-----------------------------------------------------------
set.seed(123)
n_persons_grm <- 200
n_items_grm <- 8
n_categories <- 4

theta_grm <- rnorm(n_persons_grm, 0, 1)
discrimination_grm <- runif(n_items_grm, 0.8, 2.0)
difficulty_base <- rnorm(n_items_grm, 0, 1)

responses_grm <- matrix(NA, n_persons_grm, n_items_grm)
for (j in 1:n_items_grm) {
  # Ordered thresholds centered around the item difficulty
  thresholds <- difficulty_base[j] + seq(-1.5, 1.5, length.out = n_categories - 1)

  for (i in 1:n_persons_grm) {
    # Cumulative probabilities P(Y >= k), k = 2..K
    cum <- plogis(discrimination_grm[j] * (theta_grm[i] - thresholds))
    # Category probabilities P(Y = k)
    probs <- c(1 - cum[1], -diff(cum), cum[n_categories - 1])
    responses_grm[i, j] <- sample(1:n_categories, 1, prob = probs)
  }
}

# View response distribution for the first item
table(responses_grm[, 1])

## ----fit-grm------------------------------------------------------------------
fit_grm <- fit_irt(responses_grm, model = "GRM")

print(fit_grm)
summary(fit_grm)

## ----grm-params---------------------------------------------------------------
# Item discriminations
discriminations <- fit_grm$item_parameters$discrimination
print(head(discriminations))

# Thresholds (one per category transition)
thresholds <- fit_grm$item_parameters$thresholds
print(thresholds[[1]])  # Thresholds for first item

## ----fit-pcm------------------------------------------------------------------
# PCM constrains discrimination = 1 for all items
fit_pcm <- fit_irt(responses_grm, model = "PCM")

print(fit_pcm)

## ----fit-gpcm-----------------------------------------------------------------
fit_gpcm <- fit_irt(responses_grm, model = "GPCM")

print(fit_gpcm)

## ----nrm-simulation-----------------------------------------------------------
# Simulate nominal responses (e.g., multiple choice with plausible distractors)
set.seed(456)
responses_nrm <- matrix(sample(1:4, 200 * 8, replace = TRUE), 200, 8)

fit_nrm <- fit_irt(responses_nrm, model = "NRM")
print(fit_nrm)

## ----compare-polytomous-------------------------------------------------------
comparison_poly <- data.frame(
  Model = c("GRM", "PCM", "GPCM"),
  LogLik = c(fit_grm$logLik, fit_pcm$logLik, fit_gpcm$logLik),
  AIC = c(fit_grm$AIC, fit_pcm$AIC, fit_gpcm$AIC),
  BIC = c(fit_grm$BIC, fit_pcm$BIC, fit_gpcm$BIC)
)

print(comparison_poly)
# GRM/GPCM typically fit better than PCM if discriminations vary;
# PCM is more parsimonious (fewer parameters)

## ----dif-simulation-----------------------------------------------------------
set.seed(789)
n_persons_dif <- 300
n_items_dif <- 12

group <- rep(c("Group A", "Group B"), each = n_persons_dif / 2)
theta_dif <- rnorm(n_persons_dif, 0, 1)

difficulty_dif <- rnorm(n_items_dif, 0, 1)
discrimination_dif <- runif(n_items_dif, 0.8, 2.0)

# Add uniform DIF to items 3, 6, and 9 for Group B
dif_items <- c(3, 6, 9)
dif_amount <- c(0.8, 1.2, -0.6)

responses_dif <- matrix(NA, n_persons_dif, n_items_dif)
for (i in 1:n_persons_dif) {
  for (j in 1:n_items_dif) {
    diff_effective <- difficulty_dif[j]
    if (j %in% dif_items && group[i] == "Group B") {
      diff_effective <- diff_effective + dif_amount[which(dif_items == j)]
    }
    p <- plogis(discrimination_dif[j] * (theta_dif[i] - diff_effective))
    responses_dif[i, j] <- rbinom(1, 1, p)
  }
}

## ----dif-test-----------------------------------------------------------------
dif_result <- dif_test_with_data(
  responses_dif,
  group = group,
  model = "2PL",
  alpha = 0.05
)

print(dif_result)

## ----dif-interpret------------------------------------------------------------
summary(dif_result)

# Items flagged for DIF
cat("Flagged items:", dif_result$flagged_items, "\n")

# Effect sizes for flagged items
dif_results_df <- dif_result$dif_results
flagged_df <- dif_results_df[dif_results_df$item %in% dif_result$flagged_items, ]
print(flagged_df)

# Effect size interpretation (standardized difficulty difference):
# |effect| < 0.3: negligible; 0.3-0.5: moderate; >= 0.5: large

## ----dif-plot-----------------------------------------------------------------
# Plot ICCs by group for an item with simulated DIF
dif_plot(dif_result, item = 3)

## ----dif-polytomous-----------------------------------------------------------
# DIF analysis also works with polytomous models
dif_result_grm <- dif_test_with_data(
  responses_grm,
  group = sample(c("Male", "Female"), nrow(responses_grm), replace = TRUE),
  model = "GRM",
  alpha = 0.05
)

print(dif_result_grm)

## ----eirt-setup---------------------------------------------------------------
set.seed(111)
n_persons_eirt <- 300
n_items_eirt <- 15

# Item characteristics
item_data <- data.frame(
  word_frequency = rnorm(n_items_eirt, 0, 1),  # Higher = more common words
  passage_length = rpois(n_items_eirt, 100),   # Length in words
  item_type = factor(sample(c("Literal", "Inferential", "Critical"),
                            n_items_eirt, replace = TRUE))
)

# True covariate effects
theta_eirt <- rnorm(n_persons_eirt, 0, 1)

difficulty_eirt <- -0.6 * item_data$word_frequency +
                    0.003 * item_data$passage_length +
                    rnorm(n_items_eirt, 0, 0.3)

discrimination_eirt <- exp(0.3 +
                           0.4 * (item_data$item_type == "Inferential") +
                           0.6 * (item_data$item_type == "Critical") +
                           rnorm(n_items_eirt, 0, 0.2))

responses_eirt <- matrix(NA, n_persons_eirt, n_items_eirt)
for (j in 1:n_items_eirt) {
  p <- plogis(discrimination_eirt[j] * (theta_eirt - difficulty_eirt[j]))
  responses_eirt[, j] <- rbinom(n_persons_eirt, 1, p)
}

## ----fit-eirt-----------------------------------------------------------------
fit_eirt_model <- fit_eirt(
  responses_eirt,
  item_data = item_data,
  difficulty_formula = ~ word_frequency + passage_length,
  discrimination_formula = ~ item_type,
  model = "2PL"
)

print(fit_eirt_model)

## ----eirt-results-------------------------------------------------------------
# Difficulty regression coefficients
gamma_hat <- fit_eirt_model$regression_coefficients$difficulty
print(gamma_hat)
# Negative word_frequency: items with common words are easier
# Positive passage_length: longer passages are harder

# Discrimination regression coefficients (log scale)
delta_hat <- fit_eirt_model$regression_coefficients$discrimination
print(delta_hat)
# Positive coefficients for Inferential/Critical: those item types
# discriminate better than Literal items

# Residual standard deviations: variation remaining after covariates
print(fit_eirt_model$residual_sd)

## ----eirt-comparison----------------------------------------------------------
fit_standard <- fit_irt(responses_eirt, model = "2PL")

cat("Standard IRT:    logLik =", round(fit_standard$logLik, 1),
    " AIC =", round(fit_standard$AIC, 1), "\n")
cat("Explanatory IRT: logLik =", round(fit_eirt_model$logLik, 1),
    " AIC =", round(fit_eirt_model$AIC, 1), "\n")

# EIRT can have better AIC when covariates explain substantial variation,
# and always provides interpretable regression coefficients

## ----eirt-polytomous----------------------------------------------------------
# Item characteristics for the Likert-scale (GRM) items
item_data_likert <- data.frame(
  complexity = rnorm(n_items_grm, 0, 1),
  reverse_coded = factor(sample(c("Yes", "No"), n_items_grm, replace = TRUE))
)

fit_eirt_grm <- fit_eirt(
  responses_grm,
  item_data = item_data_likert,
  difficulty_formula = ~ complexity + reverse_coded,
  discrimination_formula = ~ complexity,
  model = "GRM"
)

print(fit_eirt_grm)

## ----test-development---------------------------------------------------------
new_item <- data.frame(
  word_frequency = 0.5,  # Moderately common words
  passage_length = 90    # Short passage
)

W_new <- model.matrix(~ word_frequency + passage_length, data = new_item)
predicted_difficulty <- as.numeric(W_new %*% gamma_hat)
cat("Predicted difficulty for new item:", round(predicted_difficulty, 2), "\n")

## ----item-revision------------------------------------------------------------
predicted_diffs <- model.matrix(~ word_frequency + passage_length,
                                data = item_data) %*% gamma_hat
residuals_diff <- fit_eirt_model$item_parameters$difficulty - predicted_diffs
print(round(as.numeric(residuals_diff), 2))

