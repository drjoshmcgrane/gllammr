## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)

## ----install------------------------------------------------------------------
# Install from GitHub
# remotes::install_github("yourusername/GLLAMMR")

library(GLLAMMR)

## ----simulate-basic-----------------------------------------------------------
set.seed(123)

# Parameters
n_groups <- 30
n_per_group <- 10
beta_0 <- 2.0
beta_1 <- -0.5
sigma_u <- 0.8
sigma <- 1.2

# Generate data
group <- rep(1:n_groups, each = n_per_group)
x <- rnorm(n_groups * n_per_group)
u <- rnorm(n_groups, sd = sigma_u)
y <- beta_0 + beta_1 * x + u[group] + rnorm(n_groups * n_per_group, sd = sigma)

data <- data.frame(y = y, x = x, group = group)

# View first few rows
head(data)

## ----fit-basic----------------------------------------------------------------
fit <- gllamm(y ~ x + (1 | group),
              data = data,
              family = gaussian())

# Print results
print(fit)

## ----summary-basic------------------------------------------------------------
summary(fit)

## ----extract------------------------------------------------------------------
# Fixed effects coefficients
fixef(fit)

# Random effects (BLUPs)
ranef(fit)

# Variance components
VarCorr(fit)

# Fitted values
head(fitted(fit))

# Residuals
head(residuals(fit))

# Log-likelihood
logLik(fit)

# AIC and BIC
AIC(fit)
BIC(fit)

## ----random-slope-------------------------------------------------------------
# Simulate data with random slopes
set.seed(456)
n_groups <- 20
n_per_group <- 15

group <- rep(1:n_groups, each = n_per_group)
x <- rnorm(n_groups * n_per_group)

# Random intercepts and slopes
u0 <- rnorm(n_groups, sd = 1.0)
u1 <- rnorm(n_groups, sd = 0.5)

y <- 3.0 + 0.8 * x + u0[group] + u1[group] * x + rnorm(n_groups * n_per_group, sd = 1.5)

data_rs <- data.frame(y = y, x = x, group = group)

# Fit model with random slope
fit_rs <- gllamm(y ~ x + (x | group), data = data_rs)

summary(fit_rs)

## ----three-level--------------------------------------------------------------
# Students nested in classes nested in schools
# y_ijk = β0 + β1*x_ijk + u_school[k] + u_class[jk] + ε_ijk

# Simulate three-level data
set.seed(789)
n_schools <- 15
n_classes_per_school <- 3
n_students_per_class <- 8

n_obs <- n_schools * n_classes_per_school * n_students_per_class

school <- rep(1:n_schools, each = n_classes_per_school * n_students_per_class)
class <- rep(1:(n_schools * n_classes_per_school), each = n_students_per_class)
x <- rnorm(n_obs)

u_school <- rnorm(n_schools, sd = 1.2)
u_class <- rnorm(n_schools * n_classes_per_school, sd = 0.8)

y <- 5.0 + 0.5 * x + u_school[school] + u_class[class] + rnorm(n_obs, sd = 1.0)

data_3level <- data.frame(y = y, x = x, school = school, class = class)

# Fit three-level model
fit_3level <- gllamm(y ~ x + (1 | school/class), data = data_3level)

summary(fit_3level)

## ----prediction---------------------------------------------------------------
# Predictions with random effects (default)
pred_full <- predict(fit)

# Population-level predictions (no random effects)
pred_pop <- predict(fit, re.form = NA)

# Compare
head(data.frame(
  observed = data$y,
  fitted_with_re = pred_full,
  fitted_no_re = pred_pop
))

## ----simulation---------------------------------------------------------------
# Single simulation
sim1 <- simulate(fit, nsim = 1, seed = 999)

# Multiple simulations
sim10 <- simulate(fit, nsim = 10, seed = 999)
head(sim10)

