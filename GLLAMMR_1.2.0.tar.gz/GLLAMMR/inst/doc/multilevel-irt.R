## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  fig.width = 7,
  fig.height = 5
)

## ----simulate-data------------------------------------------------------------
# library(GLLAMMR)
# set.seed(42)
# 
# # Setup
# n_students <- 200
# n_classes <- 20
# n_items <- 15
# 
# # Create person-level data
# person_data <- data.frame(
#   student_id = 1:n_students,
#   class_id = rep(1:n_classes, each = n_students / n_classes)
# )
# 
# # Generate abilities with class effects
# sigma_person <- 1.0   # Person-level SD
# sigma_class <- 0.5    # Class-level SD
# 
# theta_0 <- rnorm(n_students, 0, sigma_person)  # Individual deviations
# u_class <- rnorm(n_classes, 0, sigma_class)    # Class effects
# theta_total <- theta_0 + u_class[person_data$class_id]
# 
# # Generate item parameters
# difficulty <- rnorm(n_items, 0, 1)
# discrimination <- rlnorm(n_items, 0, 0.3)
# 
# # Generate responses
# responses <- matrix(NA, n_students, n_items)
# for (i in 1:n_students) {
#   for (j in 1:n_items) {
#     p <- plogis(discrimination[j] * (theta_total[i] - difficulty[j]))
#     responses[i, j] <- rbinom(1, 1, p)
#   }
# }
# 
# head(person_data)

## ----fit-standard-------------------------------------------------------------
# fit_standard <- fit_irt(responses, model = "2PL")
# print(fit_standard)

## ----fit-multilevel-----------------------------------------------------------
# fit_multilevel <- fit_irt(
#   response_matrix = responses,
#   model = "2PL",
#   person_data = person_data,
#   random = ~ (1 | class_id)
# )
# 
# print(fit_multilevel)

## ----varcorr------------------------------------------------------------------
# vc <- VarCorr(fit_multilevel)
# print(vc)

## ----icc----------------------------------------------------------------------
# # All ICCs
# icc_all <- icc(fit_multilevel)
# print(icc_all)
# 
# # Specific level
# icc_class <- icc(fit_multilevel, level = "class_id")
# cat("\nICC for class level:", round(icc_class, 3), "\n")

## ----ranef--------------------------------------------------------------------
# # All random effects
# class_effects <- ranef(fit_multilevel, level = "class_id")
# head(class_effects, 10)
# 
# # Plot class effects
# plot(class_effects, main = "Estimated Class Effects",
#      xlab = "Class", ylab = "Effect (u_class)")
# abline(h = 0, lty = 2, col = "red")

## ----abilities----------------------------------------------------------------
# # Person-level deviations only
# theta_0 <- abilities(fit_multilevel, composite = FALSE)
# 
# # Composite abilities (person + class)
# theta_composite <- abilities(fit_multilevel, composite = TRUE)
# 
# # Compare
# plot(theta_0, theta_composite,
#      xlab = "Person Deviation (theta_0)",
#      ylab = "Composite Ability (theta_0 + u_class)",
#      main = "Person vs Composite Abilities")
# abline(0, 1, lty = 2, col = "red")

## ----compare------------------------------------------------------------------
# cat("Standard Model:\n")
# cat("  Log-likelihood:", round(fit_standard$logLik, 2), "\n")
# cat("  AIC:", round(fit_standard$AIC, 2), "\n\n")
# 
# cat("Multi-level Model:\n")
# cat("  Log-likelihood:", round(fit_multilevel$logLik, 2), "\n")
# cat("  AIC:", round(fit_multilevel$AIC, 2), "\n\n")
# 
# # Likelihood ratio test
# lr_stat <- 2 * (fit_multilevel$logLik - fit_standard$logLik)
# df_diff <- 1  # One additional variance parameter
# p_value <- pchisq(lr_stat, df = df_diff, lower.tail = FALSE)
# 
# cat("Likelihood Ratio Test:\n")
# cat("  LR statistic:", round(lr_stat, 2), "\n")
# cat("  df:", df_diff, "\n")
# cat("  p-value:", format.pval(p_value), "\n")

## ----nested-example, eval=FALSE-----------------------------------------------
# # Create nested structure
# person_data_nested <- data.frame(
#   student_id = 1:200,
#   school_id = rep(1:5, each = 40),
#   class_id = rep(1:20, each = 10)
# )
# 
# # Nested notation (school/class)
# fit_nested1 <- fit_irt(
#   responses,
#   model = "2PL",
#   person_data = person_data_nested,
#   random = ~ (1 | school_id/class_id)
# )
# 
# # Equivalent explicit notation
# fit_nested2 <- fit_irt(
#   responses,
#   model = "2PL",
#   person_data = person_data_nested,
#   random = ~ (1 | school_id) + (1 | class_id)
# )
# 
# # Both specifications are equivalent
# print(fit_nested1)

## ----crossed-example, eval=FALSE----------------------------------------------
# # Simulate longitudinal data
# n_students <- 100
# n_timepoints <- 3
# n_items <- 10
# 
# long_data <- expand.grid(
#   student_id = 1:n_students,
#   time = 1:n_timepoints
# )
# long_data$obs_id <- 1:nrow(long_data)
# 
# # Generate responses (rows = observations, cols = items)
# responses_long <- matrix(rbinom(nrow(long_data) * n_items, 1, 0.6),
#                          nrow(long_data), n_items)
# 
# # Crossed random effects
# fit_crossed <- fit_irt(
#   responses_long,
#   model = "2PL",
#   person_data = long_data,
#   random = ~ (1 | student_id) + (1 | time)
# )
# 
# print(fit_crossed)

## ----partial-nesting, eval=FALSE----------------------------------------------
# # Set some students to NA (not in any class)
# person_data_partial <- person_data
# person_data_partial$class_id[191:200] <- NA
# 
# # Fit with partial nesting
# fit_partial <- fit_irt(
#   responses,
#   model = "2PL",
#   person_data = person_data_partial,
#   random = ~ (1 | class_id)
# )
# 
# print(fit_partial)
# # Note: Number of groups will be less than 20 (excludes NA class)

## ----polytomous, eval=FALSE---------------------------------------------------
# # Simulate 4-category responses
# responses_poly <- matrix(sample(1:4, n_students * n_items, replace = TRUE),
#                          n_students, n_items)
# 
# # Fit multi-level GRM
# fit_grm_ml <- fit_irt(
#   responses_poly,
#   model = "GRM",
#   person_data = person_data,
#   random = ~ (1 | class_id)
# )
# 
# print(fit_grm_ml)

## ----session-info-------------------------------------------------------------
# sessionInfo()

