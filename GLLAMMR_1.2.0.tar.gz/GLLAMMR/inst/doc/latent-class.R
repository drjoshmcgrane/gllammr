## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----simulate-lca-------------------------------------------------------------
# library(GLLAMMR)
# 
# set.seed(123)
# n <- 500
# n_items <- 6
# 
# # Two latent classes with distinct response patterns
# # Class 1: "High endorsers" - frequently say yes
# class1_probs <- c(0.85, 0.75, 0.90, 0.80, 0.85, 0.70)
# 
# # Class 2: "Low endorsers" - infrequently say yes
# class2_probs <- c(0.15, 0.25, 0.10, 0.20, 0.15, 0.30)
# 
# # 60% in class 1, 40% in class 2
# true_class <- sample(1:2, n, replace = TRUE, prob = c(0.6, 0.4))
# 
# # Generate item responses
# data <- matrix(NA, n, n_items)
# for (i in 1:n) {
#   probs <- if (true_class[i] == 1) class1_probs else class2_probs
#   data[i, ] <- rbinom(n_items, 1, probs)
# }
# 
# colnames(data) <- paste0("Item", 1:n_items)
# head(data)

## ----fit-2class---------------------------------------------------------------
# fit_2class <- fit_lca(data, nclass = 2)
# 
# print(fit_2class)

## ----class-sizes--------------------------------------------------------------
# # Modal class assignment
# table(fit_2class$modal_class)
# 
# # Compare to true classes
# if (exists("true_class")) {
#   # Confusion matrix (may need to relabel)
#   table(True = true_class, Estimated = fit_2class$modal_class)
# 
#   # Classification accuracy (best of two label permutations)
#   acc1 <- mean(fit_2class$modal_class == true_class)
#   acc2 <- mean(fit_2class$modal_class == (3 - true_class))
#   cat("Classification accuracy:", max(acc1, acc2), "\n")
# }

## ----item-probs---------------------------------------------------------------
# # Item probabilities by class
# print(round(fit_2class$item_probs, 3))
# 
# # Visualize item profiles
# barplot(t(fit_2class$item_probs),
#         beside = TRUE,
#         legend.text = paste("Class", 1:2),
#         xlab = "Item",
#         ylab = "P(Endorse)",
#         main = "Item Response Profiles by Class",
#         col = c("lightblue", "lightcoral"))

## ----posterior----------------------------------------------------------------
# # First few individuals' posterior class probabilities
# head(fit_2class$posterior)
# 
# # How certain are we about class membership?
# # High max posterior = high certainty
# max_posterior <- apply(fit_2class$posterior, 1, max)
# 
# hist(max_posterior,
#      main = "Distribution of Maximum Posterior Probabilities",
#      xlab = "Max Posterior Probability",
#      col = "lightgreen",
#      breaks = 20)
# 
# # Individuals with uncertain classification
# uncertain <- which(max_posterior < 0.7)
# cat("Number of uncertain classifications:", length(uncertain), "\n")

## ----model-selection----------------------------------------------------------
# # Fit models with different numbers of classes
# fit_1class <- fit_lca(data, nclass = 1)  # Null model
# fit_2class <- fit_lca(data, nclass = 2)
# fit_3class <- fit_lca(data, nclass = 3)
# fit_4class <- fit_lca(data, nclass = 4)
# 
# # Compare fit statistics
# model_comparison <- data.frame(
#   nclass = 1:4,
#   LogLik = c(fit_1class$logLik, fit_2class$logLik,
#              fit_3class$logLik, fit_4class$logLik),
#   AIC = c(fit_1class$AIC, fit_2class$AIC,
#           fit_3class$AIC, fit_4class$AIC),
#   BIC = c(fit_1class$BIC, fit_2class$BIC,
#           fit_3class$BIC, fit_4class$BIC)
# )
# 
# print(model_comparison)
# 
# # Plot BIC by number of classes
# plot(model_comparison$nclass, model_comparison$BIC,
#      type = "b", lwd = 2, pch = 19,
#      xlab = "Number of Classes",
#      ylab = "BIC",
#      main = "Model Selection via BIC")
# 
# # Lowest BIC is preferred
# best_model <- which.min(model_comparison$BIC)
# cat("Best model (by BIC):", best_model, "classes\n")

## ----interpret----------------------------------------------------------------
# # Example: Assuming fit_2class is the best model
# class_profiles <- fit_2class$item_probs
# 
# # Class 1: High on all items -> "High Symptom" group
# # Class 2: Low on all items -> "Low Symptom" group
# 
# class_names <- c("High Symptom", "Low Symptom")
# 
# # Or for more nuanced patterns:
# # Class 1: High on items 1-3, low on 4-6 -> "Anxious" subtype
# # Class 2: Low on items 1-3, high on 4-6 -> "Depressed" subtype

## ----profiling, eval=FALSE----------------------------------------------------
# # If you have additional covariates (not used in LCA)
# # you can profile the classes
# 
# # Example: Are classes related to age or gender?
# # (Assuming we have these variables)
# 
# # age_by_class <- tapply(age, fit_2class$modal_class, mean)
# # gender_by_class <- table(gender, fit_2class$modal_class)

## ----depression-example, eval=FALSE-------------------------------------------
# # Simulate depression symptom data
# set.seed(456)
# n_patients <- 600
# symptoms <- c("Sad", "Tired", "Insomnia", "Appetite", "Guilt",
#               "Concentration", "Psychomotor", "Suicidal", "Anhedonia")
# n_symptoms <- length(symptoms)
# 
# # Three classes:
# # 1. Severe (high on all)
# # 2. Moderate (medium on most)
# # 3. Mild (low on most)
# 
# severe_probs <- rep(0.85, n_symptoms)
# moderate_probs <- rep(0.50, n_symptoms)
# mild_probs <- rep(0.15, n_symptoms)
# 
# true_severity <- sample(1:3, n_patients, replace = TRUE,
#                         prob = c(0.2, 0.5, 0.3))
# 
# depression_data <- matrix(NA, n_patients, n_symptoms)
# for (i in 1:n_patients) {
#   probs <- switch(true_severity[i],
#                   severe_probs,
#                   moderate_probs,
#                   mild_probs)
#   depression_data[i, ] <- rbinom(n_symptoms, 1, probs)
# }
# 
# colnames(depression_data) <- symptoms
# 
# # Fit 3-class model
# fit_depression <- fit_lca(depression_data, nclass = 3)
# 
# print(fit_depression)
# 
# # Examine class profiles
# print(round(fit_depression$item_probs, 2))

## ----learning-strategies, eval=FALSE------------------------------------------
# # Simulate data on study strategies
# set.seed(789)
# n_students <- 400
# strategies <- c("Highlighting", "Summarizing", "Practice_Testing",
#                 "Distributed", "Interleaved", "Elaboration")
# n_strategies <- length(strategies)
# 
# # Two classes:
# # 1. "Deep learners" - use effective strategies
# # 2. "Surface learners" - use ineffective strategies
# 
# deep_probs <- c(0.3, 0.8, 0.9, 0.85, 0.7, 0.8)  # High on good strategies
# surface_probs <- c(0.9, 0.3, 0.2, 0.15, 0.2, 0.3)  # High on highlighting only
# 
# true_type <- sample(1:2, n_students, replace = TRUE, prob = c(0.4, 0.6))
# 
# strategy_data <- matrix(NA, n_students, n_strategies)
# for (i in 1:n_students) {
#   probs <- if (true_type[i] == 1) deep_probs else surface_probs
#   strategy_data[i, ] <- rbinom(n_strategies, 1, probs)
# }
# 
# colnames(strategy_data) <- strategies
# 
# # Fit model
# fit_strategies <- fit_lca(strategy_data, nclass = 2)
# 
# print(fit_strategies)
# 
# # Interpret classes
# print(round(fit_strategies$item_probs, 2))
# 
# # Deep learners should show high use of:
# # - Practice testing
# # - Distributed practice
# # - Interleaving
# # - Elaboration

## ----marketing, eval=FALSE----------------------------------------------------
# # Simulate customer purchase patterns
# set.seed(111)
# n_customers <- 800
# products <- c("Premium", "Budget", "Frequent", "Bulk",
#               "Online", "Loyalty", "Reviews")
# n_products <- length(products)
# 
# # Three customer segments:
# # 1. "Premium shoppers"
# # 2. "Budget hunters"
# # 3. "Occasional buyers"
# 
# premium_probs <- c(0.9, 0.1, 0.8, 0.3, 0.9, 0.8, 0.7)
# budget_probs <- c(0.1, 0.9, 0.6, 0.8, 0.5, 0.4, 0.8)
# occasional_probs <- c(0.3, 0.5, 0.2, 0.1, 0.4, 0.2, 0.3)
# 
# true_segment <- sample(1:3, n_customers, replace = TRUE,
#                        prob = c(0.25, 0.45, 0.30))
# 
# customer_data <- matrix(NA, n_customers, n_products)
# for (i in 1:n_customers) {
#   probs <- switch(true_segment[i],
#                   premium_probs,
#                   budget_probs,
#                   occasional_probs)
#   customer_data[i, ] <- rbinom(n_products, 1, probs)
# }
# 
# colnames(customer_data) <- products
# 
# # Fit model
# fit_customers <- fit_lca(customer_data, nclass = 3)
# 
# print(fit_customers)
# 
# # Target marketing strategies based on segments
# print(round(fit_customers$item_probs, 2))

## ----local-indep, eval=FALSE--------------------------------------------------
# # Compare observed and expected cell frequencies
# # High residuals suggest local dependence
# 
# # This would require additional functionality:
# # check_local_independence(fit_2class)

## ----classification-diag------------------------------------------------------
# # Entropy: measure of classification uncertainty
# # Ranges from 0 (complete uncertainty) to 1 (perfect certainty)
# 
# compute_entropy <- function(posterior) {
#   # Avoid log(0)
#   posterior[posterior == 0] <- 1e-10
# 
#   # Entropy formula
#   entropy_i <- -rowSums(posterior * log(posterior))
#   max_entropy <- log(ncol(posterior))
# 
#   # Relative entropy (0 to 1)
#   rel_entropy <- 1 - mean(entropy_i) / max_entropy
# 
#   return(rel_entropy)
# }
# 
# entropy <- compute_entropy(fit_2class$posterior)
# cat("Entropy:", round(entropy, 3), "\n")
# 
# # Entropy > 0.8 is considered good separation

## ----lcr, eval=FALSE----------------------------------------------------------
# # Future feature: Include covariates predicting class membership
# # fit_lcr <- fit_lca(data, nclass = 2, formula = ~ age + gender)

## ----gmm, eval=FALSE----------------------------------------------------------
# # Future feature: Combine LCA with growth curves
# # fit_gmm <- fit_growth_mixture(y ~ time | id, nclass = 3)

## ----lc-irt, eval=FALSE-------------------------------------------------------
# # Future feature: IRT models with discrete ability distribution
# # fit_lc_irt <- fit_irt(responses, nclass = 3)

