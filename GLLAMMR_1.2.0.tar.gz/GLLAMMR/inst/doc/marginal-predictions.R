## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 6,
  fig.height = 4.5,
  eval = TRUE
)

## ----binomial_example---------------------------------------------------------
library(GLLAMMR)
set.seed(123)

# Simulate data: treatment effect with clinic random effects
n_clinics <- 20
n_per_clinic <- 25
n <- n_clinics * n_per_clinic
u_clinic <- rnorm(n_clinics, 0, 1)

data <- data.frame(
  treatment = rep(0:1, each = n / 2),
  clinic = factor(rep(1:n_clinics, each = n_per_clinic))
)
data$success <- rbinom(
  n, 1,
  plogis(-0.2 + 0.8 * data$treatment + u_clinic[as.integer(data$clinic)])
)

# Fit binomial GLMM (stats::binomial uses the general TMB estimator)
fit <- gllamm(success ~ treatment + (1 | clinic),
              data = data,
              family = stats::binomial())

# Conditional predictions (at u = 0)
pred_cond <- predict(fit, type = "response", re.form = NA)

# Marginal predictions (averaged over clinics)
pred_marg <- predict(fit, type = "marginal", n_sim = 1000)

# Compare
summary(pred_cond - pred_marg)

## ----plot_comparison----------------------------------------------------------
plot(pred_cond, pred_marg,
     xlab = "Conditional Prediction (u = 0)",
     ylab = "Marginal Prediction",
     main = "Conditional vs Marginal Predictions",
     pch = 19, col = rgb(0, 0, 0, 0.3))
abline(0, 1, col = "red", lwd = 2)

## ----ordinal_example----------------------------------------------------------
set.seed(456)
data_ord <- data.frame(
  rating = sample(1:5, n, replace = TRUE),
  temp = rnorm(n),
  judge = factor(rep(1:n_clinics, each = n_per_clinic))
)

# Fit proportional odds model
fit_ord <- gllamm(rating ~ temp + (1 | judge),
                  data = data_ord,
                  family = ordinal(link = "logit"))

# Marginal category probabilities (n_obs x n_categories matrix)
pred_marg_ord <- predict(fit_ord, type = "marginal", n_sim = 500)

# Average marginal probabilities: expected population proportions
# of each rating category, accounting for between-judge variability
round(colMeans(pred_marg_ord), 3)

## ----irt_example--------------------------------------------------------------
set.seed(789)
n_persons <- 200
n_items <- 10

theta <- rnorm(n_persons)
b_item <- seq(-1.5, 1.5, length.out = n_items)
responses <- sapply(b_item, function(b) rbinom(n_persons, 1, plogis(theta - b)))

# Fit 2PL model
fit_2pl <- fit_irt(responses, model = "2PL")

# Marginal item response probabilities (one per item)
pred_marg_irt <- predict(fit_2pl, type = "marginal", n_sim = 1000)

# Compare to empirical proportions correct
emp_props <- colMeans(responses)

plot(emp_props, pred_marg_irt,
     xlab = "Empirical Proportion Correct",
     ylab = "Predicted Marginal Probability",
     main = "IRT: Empirical vs Predicted",
     pch = 19, cex = 1.5, col = "blue")
abline(0, 1, col = "red", lwd = 2)

## ----eirt_example-------------------------------------------------------------
# Item data with predictors
item_data <- data.frame(
  item_id = 1:n_items,
  item_length = rnorm(n_items),
  content_area = factor(sample(c("Algebra", "Geometry"), n_items, replace = TRUE))
)

# Fit EIRT model
fit_eirt_model <- fit_eirt(responses,
                           item_data = item_data,
                           difficulty_formula = ~ item_length + content_area,
                           model = "2PL")

# Predict for new (not yet administered) items
new_items <- data.frame(
  item_length = c(-1, 0, 1),
  content_area = factor(c("Algebra", "Algebra", "Geometry"))
)

pred_new <- predict(fit_eirt_model,
                    newdata = new_items,
                    type = "marginal",
                    n_sim = 500)

data.frame(
  item_length = new_items$item_length,
  content_area = new_items$content_area,
  pred_prob = round(as.numeric(pred_new), 3)
)

## ----multinomial_example------------------------------------------------------
set.seed(321)
data_mult <- data.frame(
  choice = sample(0:2, n, replace = TRUE),
  price = rnorm(n),
  quality = rnorm(n),
  person = factor(rep(1:100, length.out = n))
)

# Fit multinomial logit model with a person-level random effect
fit_mult <- fit_multinomial(choice ~ price + quality + (1 | person),
                            data = data_mult)

# Marginal category probabilities
pred_marg_mult <- predict(fit_mult, type = "marginal", n_sim = 500)

# Population-level choice shares
round(colMeans(pred_marg_mult), 3)

## ----survival_example---------------------------------------------------------
set.seed(654)
n_hospitals <- 20
u_hosp <- rnorm(n_hospitals, 0, 0.5)

data_surv <- data.frame(
  treatment = rep(0:1, each = n / 2),
  hospital = factor(rep(1:n_hospitals, each = n / n_hospitals))
)
t_true <- rexp(n, rate = exp(-2.5 + 0.5 * data_surv$treatment +
                             u_hosp[as.integer(data_surv$hospital)]))
cens <- rexp(n, rate = 0.05)
data_surv$time <- pmin(t_true, cens)
data_surv$status <- as.integer(t_true <= cens)

# Fit Weibull survival model with hospital frailty
fit_surv <- fit_survival(Surv(time, status) ~ treatment + (1 | hospital),
                         data = data_surv,
                         distribution = "weibull")

# Marginal survival probabilities at selected times
times <- c(5, 10, 15, 20, 25)
surv_marg <- predict(fit_surv,
                     type = "marginal_survival",
                     times = times,
                     n_sim = 500)

# Population-average survival curve
avg_surv <- colMeans(surv_marg)

plot(times, avg_surv, type = "b",
     xlab = "Time", ylab = "Survival Probability",
     main = "Population-Average Survival Curve",
     ylim = c(0, 1), pch = 19, col = "blue", lwd = 2)
grid()

## ----se_example---------------------------------------------------------------
pred_with_se <- predict(fit, type = "marginal", n_sim = 500, se.fit = TRUE)
str(pred_with_se)

## ----gaussian_optimization----------------------------------------------------
set.seed(987)
data_g <- data.frame(
  y = rnorm(200), x = rnorm(200),
  group = factor(rep(1:20, each = 10))
)
fit_gauss <- gllamm(y ~ x + (1 | group), data = data_g, family = gaussian())

pred_fixed <- predict(fit_gauss, re.form = NA)
pred_marg_g <- predict(fit_gauss, type = "marginal")

max(abs(pred_fixed - pred_marg_g))

