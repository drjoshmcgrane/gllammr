## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# gllamm(math_score ~ ses + (1 | school),
#        data = mydata,
#        family = gaussian())

## -----------------------------------------------------------------------------
# gllamm(math_score ~ ses + (ses | school),
#        data = mydata)

## -----------------------------------------------------------------------------
# gllamm(passed ~ hours + (1 | school),
#        family = binomial(link = "logit"))

## -----------------------------------------------------------------------------
# # Load data
# data <- read.csv("schooldata.csv")
# 
# # Fit model
# fit <- gllamm(math ~ ses + (1 | school),
#               data = data,
#               family = gaussian())
# 
# # Predictions
# fitted_vals <- fitted(fit)
# random_effects <- ranef(fit)
# 
# # Results
# summary(fit)
# exp(coef(fit))  # Exponentiated coefficients

## -----------------------------------------------------------------------------
# fit1 <- gllamm(attain ~ standLRT, + (1 | school),
#                data = gcse)

## -----------------------------------------------------------------------------
# fit_irt <- fit_irt(response_matrix, model = "2PL")

## -----------------------------------------------------------------------------
# fit_lca <- fit_lca(indicators, nclass = 3)

