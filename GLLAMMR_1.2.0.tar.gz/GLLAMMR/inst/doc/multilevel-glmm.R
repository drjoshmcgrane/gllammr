## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# library(GLLAMMR)
# 
# # Students in schools
# fit1 <- gllamm(math_score ~ ses + (1 | school),
#                data = school_data,
#                family = gaussian())
# summary(fit1)

## -----------------------------------------------------------------------------
# # Random slope for SES
# fit2 <- gllamm(math_score ~ ses + (ses | school),
#                data = school_data)
# summary(fit2)

## -----------------------------------------------------------------------------
# # Students in classes in schools
# fit3 <- gllamm(achievement ~ time + (1 | school/class),
#                data = multilevel_data)

## -----------------------------------------------------------------------------
# fit4 <- gllamm(passed ~ hours_studied + (1 | school),
#                family = binomial())

## -----------------------------------------------------------------------------
# fit5 <- gllamm(num_visits ~ treatment + (1 | clinic),
#                family = poisson())

## -----------------------------------------------------------------------------
# fit6 <- fit_ordinal(satisfaction ~ service_quality + (1 | store),
#                     data = customer_data)

## -----------------------------------------------------------------------------
# # Standard diagnostic plots
# plot(fit1)
# 
# # Goodness of fit
# gof.gllamm(fit1)
# 
# # ICC
# icc(fit1)

## -----------------------------------------------------------------------------
# AIC(fit1, fit2)
# BIC(fit1, fit2)

