## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# library(GLLAMMR)
# 
# # Continuous + Binary outcomes sharing random effects
# fit_mixed <- fit_mixed_response(
#   formulas = list(
#     continuous = score ~ time + (1 | id),
#     binary = improved ~ time + (1 | id)
#   ),
#   data = clinical_data
# )

## -----------------------------------------------------------------------------
# fit_surv <- fit_survival(
#   Surv(time, event) ~ treatment + (1 | clinic),
#   data = survival_data,
#   distribution = "weibull"
# )

## -----------------------------------------------------------------------------
# fit_ord <- fit_ordinal(
#   pain_level ~ treatment + time + (1 | patient),
#   data = pain_data,
#   link = "logit"
# )

## -----------------------------------------------------------------------------
# fit_multi <- fit_multinomial(
#   choice ~ price + quality + (1 | person),
#   data = choice_data
# )

## -----------------------------------------------------------------------------
# # Comprehensive diagnostics
# plot(fit)
# gof.gllamm(fit)
# influence(fit)
# find_outliers(fit)
# 
# # ICC
# icc(fit)

